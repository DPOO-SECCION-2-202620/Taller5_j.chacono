package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import java.io.FileNotFoundException;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import uniandes.dpoo.hamburguesas.excepciones.NoHayPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.excepciones.YaHayUnPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.mundo.Restaurante;
import static org.junit.jupiter.api.Assertions.assertThrows;

import uniandes.dpoo.hamburguesas.excepciones.IngredienteRepetidoException;
import uniandes.dpoo.hamburguesas.excepciones.ProductoFaltanteException;
import uniandes.dpoo.hamburguesas.excepciones.ProductoRepetidoException;

public class RestauranteTest
{
    @Test
    public void testIniciarPedidoYExcepciones() throws Exception
    {
        Restaurante restaurante = new Restaurante();

        assertNull(restaurante.getPedidoEnCurso());
        assertThrows(NoHayPedidoEnCursoException.class,
                () -> restaurante.cerrarYGuardarPedido());

        restaurante.iniciarPedido("Ana", "Calle 10");
        assertNotNull(restaurante.getPedidoEnCurso());

        assertThrows(YaHayUnPedidoEnCursoException.class,
                () -> restaurante.iniciarPedido("Luis", "Calle 20"));
    }

    @Test
    public void testCargarInformacion(@TempDir Path carpeta) throws Exception
    {
        File ingredientes = carpeta.resolve("ingredientes.txt").toFile();
        File menu = carpeta.resolve("menu.txt").toFile();
        File combos = carpeta.resolve("combos.txt").toFile();

        Files.write(ingredientes.toPath(),
        		"Queso;1500\n\n".getBytes(StandardCharsets.UTF_8));
        Files.write(menu.toPath(),
        		"Hamburguesa;10000\n\nPapas;5000\n".getBytes(StandardCharsets.UTF_8));
        Files.write(combos.toPath(),
                "Especial;10%;Hamburguesa;Papas\n".getBytes(StandardCharsets.UTF_8));

        Restaurante restaurante = new Restaurante();
        restaurante.cargarInformacionRestaurante(ingredientes, menu, combos);

        assertEquals(1, restaurante.getIngredientes().size());
        assertEquals(2, restaurante.getMenuBase().size());
        assertEquals(1, restaurante.getMenuCombos().size());
        assertEquals(13500, restaurante.getMenuCombos().get(0).getPrecio());
    }

    @Test
    public void testCerrarYGuardarPedido() throws Exception
    {
        Restaurante restaurante = new Restaurante();
        restaurante.iniciarPedido("Ana", "Calle 10");

        restaurante.getPedidoEnCurso().agregarProducto(
                new ProductoMenu("Hamburguesa", 10000));

        int id = restaurante.getPedidoEnCurso().getIdPedido();

        new File("./facturas").mkdirs();

        restaurante.cerrarYGuardarPedido();

        File factura = new File("./facturas/factura_" + id + ".txt");
        assertNull(restaurante.getPedidoEnCurso());
        assertEquals(1, restaurante.getPedidos().size());
        assertEquals(id, restaurante.getPedidos().get(0).getIdPedido());
        assertEquals(true, factura.exists());
    }
    @Test
    public void testErroresAlCargarArchivos(@TempDir Path carpeta) throws Exception
    {
        File ingredientesRepetidos = carpeta.resolve("ingredientesRepetidos.txt").toFile();
        File ingredientesVacios = carpeta.resolve("ingredientesVacios.txt").toFile();
        File menuRepetido = carpeta.resolve("menuRepetido.txt").toFile();
        File menuValido = carpeta.resolve("menuValido.txt").toFile();
        File combosVacios = carpeta.resolve("combosVacios.txt").toFile();
        File combosRepetidos = carpeta.resolve("combosRepetidos.txt").toFile();
        File comboConProductoFaltante = carpeta.resolve("comboFaltante.txt").toFile();

        Files.write(ingredientesRepetidos.toPath(),
                "Queso;1500\nQueso;1500\n".getBytes(StandardCharsets.UTF_8));
        Files.write(ingredientesVacios.toPath(),
                new byte[0]);
        Files.write(menuRepetido.toPath(),
                "Hamburguesa;10000\nHamburguesa;10000\n".getBytes(StandardCharsets.UTF_8));
        Files.write(menuValido.toPath(),
                "Hamburguesa;10000\n".getBytes(StandardCharsets.UTF_8));
        Files.write(combosVacios.toPath(),
                new byte[0]);
        Files.write(combosRepetidos.toPath(),
                ("Especial;10%;Hamburguesa\n"
               + "Especial;10%;Hamburguesa\n").getBytes(StandardCharsets.UTF_8));
        Files.write(comboConProductoFaltante.toPath(),
                "Especial;10%;NoExiste\n".getBytes(StandardCharsets.UTF_8));

        Restaurante restauranteIngredientes = new Restaurante();
        assertThrows(IngredienteRepetidoException.class,
                () -> restauranteIngredientes.cargarInformacionRestaurante(
                        ingredientesRepetidos, menuValido, combosVacios));

        Restaurante restauranteMenu = new Restaurante();
        assertThrows(ProductoRepetidoException.class,
                () -> restauranteMenu.cargarInformacionRestaurante(
                        ingredientesVacios, menuRepetido, combosVacios));

        Restaurante restauranteComboRepetido = new Restaurante();
        assertThrows(ProductoRepetidoException.class,
                () -> restauranteComboRepetido.cargarInformacionRestaurante(
                        ingredientesVacios, menuValido, combosRepetidos));

        Restaurante restauranteProductoFaltante = new Restaurante();
        assertThrows(ProductoFaltanteException.class,
                () -> restauranteProductoFaltante.cargarInformacionRestaurante(
                        ingredientesVacios, menuValido, comboConProductoFaltante));
    }
    @Test
    public void testErroresDeArchivosAlCargar(@TempDir Path carpeta) throws Exception
    {
        File archivoInexistente = carpeta.resolve("noExiste.txt").toFile();
        File ingredientesMalFormados = carpeta.resolve("ingredientesMalFormados.txt").toFile();
        File menuVacio = carpeta.resolve("menuVacio.txt").toFile();
        File combosVacios = carpeta.resolve("combosVacios.txt").toFile();

        Files.write(ingredientesMalFormados.toPath(),
                "Queso;noEsNumero\n".getBytes(StandardCharsets.UTF_8));
        Files.write(menuVacio.toPath(), new byte[0]);
        Files.write(combosVacios.toPath(), new byte[0]);

        Restaurante restauranteArchivoInexistente = new Restaurante();
        assertThrows(FileNotFoundException.class,
                () -> restauranteArchivoInexistente.cargarInformacionRestaurante(
                        archivoInexistente, menuVacio, combosVacios));

        Restaurante restauranteMalFormado = new Restaurante();
        assertThrows(NumberFormatException.class,
                () -> restauranteMalFormado.cargarInformacionRestaurante(
                        ingredientesMalFormados, menuVacio, combosVacios));
    }
}