package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ComboTest
{
    @Test
    public void testComboConDescuento()
    {
        ArrayList<ProductoMenu> productos = new ArrayList<>();
        productos.add(new ProductoMenu("Hamburguesa", 10000));
        productos.add(new ProductoMenu("Papas", 5000));

        Combo combo = new Combo("Especial", 0.10, productos);

        assertEquals("Especial", combo.getNombre());
        assertEquals(13500, combo.getPrecio());
        assertEquals(
                "Combo Especial\n"
              + " Descuento: 0.1\n"
              + "            13500\n",
                combo.generarTextoFactura());
    }
}