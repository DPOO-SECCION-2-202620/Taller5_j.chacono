package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class PedidoTest
{
    @Test
    public void testDatosDelPedido()
    {
        Pedido pedido1 = new Pedido("Ana", "Calle 10");
        Pedido pedido2 = new Pedido("Luis", "Calle 20");

        assertEquals("Ana", pedido1.getNombreCliente());
        assertEquals(pedido1.getIdPedido() + 1, pedido2.getIdPedido());
    }

    @Test
    public void testFacturaYPrecioTotal()
    {
        Pedido pedido = new Pedido("Ana", "Calle 10");
        ProductoMenu hamburguesa = new ProductoMenu("Hamburguesa", 10000);
        ProductoMenu papas = new ProductoMenu("Papas", 5000);

        pedido.agregarProducto(hamburguesa);
        pedido.agregarProducto(papas);

        assertEquals(17850, pedido.getPrecioTotalPedido());

        String facturaEsperada =
                "Cliente: Ana\n"
              + "Dirección: Calle 10\n"
              + "----------------\n"
              + "Hamburguesa\n"
              + "            10000\n"
              + "Papas\n"
              + "            5000\n"
              + "----------------\n"
              + "Precio Neto:  15000\n"
              + "IVA:          2850\n"
              + "Precio Total: 17850\n";

        assertEquals(facturaEsperada, pedido.generarTextoFactura());
    }

    @Test
    public void testGuardarFactura(@TempDir Path carpetaTemporal) throws Exception
    {
        Pedido pedido = new Pedido("Ana", "Calle 10");
        pedido.agregarProducto(new ProductoMenu("Hamburguesa", 10000));

        File archivo = carpetaTemporal.resolve("factura.txt").toFile();
        pedido.guardarFactura(archivo);

        String contenidoGuardado = new String(
                Files.readAllBytes(archivo.toPath()),
                StandardCharsets.UTF_8);

        assertTrue(archivo.exists());
        assertEquals(pedido.generarTextoFactura(), contenidoGuardado);
    }
}