package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import uniandes.dpoo.hamburguesas.mundo.Ingrediente;

import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
import static org.junit.jupiter.api.Assertions.assertTrue;
public class ProductoAjustadoTest
{
    @Test
    public void testProductoAjustadoSinCambios()
    {
        ProductoMenu base = new ProductoMenu("Hamburguesa clásica", 12000);
        ProductoAjustado ajustado = new ProductoAjustado(base);

        assertEquals("Hamburguesa clásica", ajustado.getNombre());
        assertEquals(12000, ajustado.getPrecio());
    }
    @Test
    public void testIngrediente()
    {
        Ingrediente ingrediente = new Ingrediente("Queso", 1500);

        assertEquals("Queso", ingrediente.getNombre());
        assertEquals(1500, ingrediente.getCostoAdicional());
    }
    @Test
    public void testPrecioConIngredientesAgregados()
    {
        ProductoMenu base = new ProductoMenu("Hamburguesa clásica", 12000);
        ProductoAjustado ajustado = new ProductoAjustado(base);

        ajustado.agregarIngrediente(new Ingrediente("Queso", 1500));
        ajustado.agregarIngrediente(new Ingrediente("Tocineta", 2500));

        assertEquals(16000, ajustado.getPrecio());
    }
    @Test
    public void testAjustesYFactura()
    {
        ProductoMenu base = new ProductoMenu("Hamburguesa", 12000);
        ProductoAjustado ajustado = new ProductoAjustado(base);

        ajustado.agregarIngrediente(new Ingrediente("Queso", 1500));
        ajustado.agregarIngrediente(new Ingrediente("Queso", 1500));
        ajustado.eliminarIngrediente(new Ingrediente("Tomate", 0));

        assertEquals(15000, ajustado.getPrecio());

        String factura = ajustado.generarTextoFactura();
        assertTrue(factura.contains("Hamburguesa"));
        assertTrue(factura.contains("+Queso"));
        assertTrue(factura.contains("-Tomate"));
        assertTrue(factura.contains("15000"));
    }
}