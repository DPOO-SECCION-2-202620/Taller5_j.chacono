package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ProductoMenuTest
{
    @Test
    public void testProductoMenu()
    {
        ProductoMenu producto = new ProductoMenu("Hamburguesa clásica", 12000);

        assertEquals("Hamburguesa clásica", producto.getNombre());
        assertEquals(12000, producto.getPrecio());

        String facturaEsperada =
                "Hamburguesa clásica\n"
              + "            12000\n";

        assertEquals(facturaEsperada, producto.generarTextoFactura());
    }
}